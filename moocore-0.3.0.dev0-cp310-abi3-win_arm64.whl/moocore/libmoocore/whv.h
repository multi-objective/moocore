#ifndef WHV_H
#define WHV_H
double rect_weighted_hv2d(double *data, int n, double * rectangles, int  rectangles_nrow, const double *reference);
#endif // WHV_H
