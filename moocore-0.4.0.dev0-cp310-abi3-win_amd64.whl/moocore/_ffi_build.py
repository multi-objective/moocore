"""C library compilation config.

This script is part of the compilation of the C library using CFFi.

Every time a new C function is created, its prototype must be added to the `ffibuilder.cdef` function call

The header files required must be placed in the first argument of `ffibuilder.set_source`, and any additional `.C` files must be added to the `sources` argument of `ffibuilder.set_source`

"""

from typing import Any

import os
import platform
from cffi import FFI

DEBUG = 0  # Default value.

libmoocore_h = "src/moocore/libmoocore.h"
sources_path = "src/moocore/libmoocore/"
headers = """
#include "io.h"
#include "hv.h"
#include "igd.h"
#include "nondominated.h"
#include "epsilon.h"
#include "eaf.h"
#include "r2_exact.h"
#include "whv.h"
#include "whv_hype.h"
#include "hvapprox.h"
"""
sources = [
    "avl.c",
    "eaf.c",
    "eaf3d.c",
    "eafdiff.c",
    "r2_exact.c",
    "hv.c",
    "hvapprox.c",
    "hv3dplus.c",
    "hv4d.c",
    "hvc3d.c",
    "hv_contrib.c",
    "io.c",
    "libutil.c",  # For fatal_error()
    "mt19937/mt19937.c",
    "nondominated.c",
    "pareto.c",
    "rng.c",
    "whv.c",
    "whv_hype.c",
]
sources = [sources_path + f for f in sources]


def get_config() -> Any:  # nocov
    from distutils.core import Distribution
    from distutils.sysconfig import get_config_vars

    get_config_vars()  # workaround for a bug of distutils, e.g. on OS/X
    config = Distribution().get_command_obj("config")
    return config


def uses_msvc() -> bool:  # nocov
    config = get_config()
    return bool(
        config.try_compile('#ifndef _MSC_VER\n#error "not MSVC"\n#endif')
    )


def _get_target_platform() -> str:
    arch_flags = os.environ.get("ARCHFLAGS", "")
    flags = [f for f in arch_flags.split(" ") if f.strip() != ""]
    try:
        pos = flags.index("-arch")
        return flags[pos + 1].lower()
    except ValueError:
        pass

    return platform.machine()


is_windows = platform.system() == "Windows"
is_macos = platform.system() == "Darwin"

target_platform = _get_target_platform()
is_x86_64 = target_platform in ("i686", "x86", "x86_64", "AMD64")

# Compiler flags.
MSVC_CFLAGS = [
    "/O2",  # Maximize speed
    "/GL",  # Enables whole program optimization.
    "/GS-",  # Disable buffer security check (for speed)
    "/wd4996",
    "/wd4114",
    "/DMOOCORE_SHARED_LIB",
]
MSVC_LDFLAGS = ["/LTCG"]  # Link-time optimization
GCC_CFLAGS = ["-O3", "-flto", "-fvisibility=hidden", "-g0"]
GCC_LDFLAGS: list[str] = []
if is_x86_64:
    # Compile for sufficiently old x86-64 architecture.
    MSVC_arch = ["/arch:AVX"]
    GCC_arch = ["-march=x86-64-v2"]
else:
    MSVC_arch = []
    GCC_arch = []

if is_windows and uses_msvc():
    cflags = MSVC_CFLAGS + MSVC_arch
    ldflags = MSVC_LDFLAGS + MSVC_arch
else:
    cflags = GCC_CFLAGS + GCC_arch
    # We have to include again CFLAGS so that the linking step includes them.
    ldflags = GCC_CFLAGS + GCC_arch + GCC_LDFLAGS
    if not is_macos:
        ldflags += ["-Wl,-z,now"]

# Optional sanitizer build.
if os.environ.get("MOOCORE_SANITIZE", "0") == "1":
    DEBUG = 1
    sanitizer_flags = [
        "-fsanitize=address,undefined",
        "-fno-omit-frame-pointer",
    ]
    cflags += sanitizer_flags
    ldflags += sanitizer_flags


undef_macros = []
# Compile in debug mode.
# This is not done automatically by ffibuilder.compile(debug=True) !
DEBUG = int(os.environ.get("MOOCORE_DEBUG", DEBUG))
if DEBUG >= 1:
    debug_flags = ["-Og", "-g3", "-fno-lto", "-Werror"]
    cflags += debug_flags
    ldflags += debug_flags
    undef_macros = ["NDEBUG"]

# All the above can be overridden by CFLAGS and LDFLAGS.
cflags_env = os.environ.get("CFLAGS", "").split()
cflags += cflags_env
ldflags += cflags_env + os.environ.get("LDFLAGS", "").split()

ffibuilder = FFI()
file_path = os.path.dirname(os.path.realpath(__file__))
libmoocore_path = os.path.join(file_path, "libmoocore")

with open(libmoocore_h) as f:
    ffibuilder.cdef(f.read())


ffibuilder.set_source(
    "moocore._libmoocore",
    headers,
    sources=sources,
    define_macros=[("DEBUG", str(DEBUG))],
    undef_macros=undef_macros,
    include_dirs=[libmoocore_path],
    extra_compile_args=cflags,
    extra_link_args=ldflags,
    py_limited_api=True,  # build against the stable ABI (abi3)
)

if __name__ == "__main__":
    ffibuilder.compile(verbose=True, debug=bool(DEBUG))  # nocov
