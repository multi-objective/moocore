import itertools
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator, Sequence
from typing import Any, ClassVar

import numpy as np
from numpy.typing import ArrayLike  # For type hints

from ._docsubstitute import DocSubstitute

## The CFFI library is used to create C bindings.
from ._libmoocore import ffi, lib  # ty: ignore[import-not-found]
from ._moocore import is_nondominated
from ._utils import _as_1d_float_array, _as_2d_float_array, _parse_maximise


def _remember_handle(handles, what):
    handles[what] = what


class BaseArchive(ABC):
    _lib_archive_free: ClassVar[Callable[..., Any]]
    _lib_archive_has_x_values: ClassVar[Callable[..., Any]]

    def __init__(
        self,
        dim: int,
        maximise: bool | Sequence[bool],
        keep_duplicates: bool,
        has_x_values: bool,
    ):
        if dim < 2 or dim > lib.MOOCORE_DIMENSION_MAX:
            raise ValueError(
                f"'dim' cannot be smaller than 2 or larger than {lib.MOOCORE_DIMENSION_MAX}"
            )

        self._dim = dim
        self.maximise = np.asarray(
            _parse_maximise(maximise, self._dim), dtype=bool
        )
        self._needs_sign_flip = True if self.maximise.any() else None
        # -1: maximize, 1: minimize
        self._minmax = np.where(self.maximise, -1.0, 1.0)

        self.keep_duplicates = keep_duplicates
        self._c_archive = self._setup_c_archive(keep_duplicates, has_x_values)
        if self._c_archive == ffi.NULL:
            raise MemoryError
        # ffi.gc() ensures that the pointer is registered with the GC and the C
        # destructor called.
        self._c_archive = ffi.gc(self._c_archive, self._lib_archive_free)

        # Python objects stored in C will be freed by Python unless we keep a
        # reference to them in Python. This dictionary keeps those objects alive until
        # we decide to free or move them to another front.
        self._x_handles = {}
        self._has_x_values = has_x_values
        # FIXME: Using a set() instead of a dictionary is probably faster. We
        # can store the output of ffi.new_handle() directly in the set.
        # However, when retrieving handles from C, two handles may compare
        # equal, but the one in self._x_handles is the one that should be kept
        # alive.
        self.displaced_p = ffi.NULL

    @property
    def dim(self) -> int:
        """Return the dimension of the points (objective vectors) stored in the archive."""
        return self._dim

    def has_x_values(self) -> bool:
        """Return true if the archive stores 'x' values."""
        # FIXME: enable the assert only when testing.
        assert (
            self._lib_archive_has_x_values(self._c_archive)
            == self._has_x_values
        )
        return self._has_x_values

    @abstractmethod
    def _setup_c_archive(self, keep_duplicates: bool, has_x_values: bool):
        pass

    def _objectives_to_c(self, z: ArrayLike):
        # We do not want to modify the original array, so we force a copy here.
        ## FIXME: The C archive should handle minmax to avoid this extra
        ## copy. However, this is not as trivial as it sounds. The C code needs
        ## to apply minmax at the entry point, but for that, it needs to create
        ## a copy even if the solution ends up being rejected.  An idea is the
        ## following: The base archive keeps a const double * z_tmp array
        ## already allocated. The entry points use this memory and apply normalization to it. If the point is
        ## accepted, then a new slot z_tmp is allocated. If the point is
        ## rejected, then no allocation nor free happens. The slot is freed
        ## when the archive is freed.

        z = _as_1d_float_array(
            z, dim=self.dim, name="z", copy=self._needs_sign_flip
        )
        if self._needs_sign_flip:
            z *= self._minmax
        return ffi.from_buffer("double []", z)


class BaseUnboundedArchive(BaseArchive):
    """Interface implemented by objects returned by :func:`UnboundedArchive`.

    This class defines the common interface for ``BaseUnboundedArchive``
    objects.  It is not intended to be instantiated directly.  See Examples in
    :func:`UnboundedArchive`.

    """

    # Derived classes must define these:
    _lib_archive_add_and_discard: ClassVar[Callable[..., Any]]
    _lib_archive_add_and_get_displaced: ClassVar[Callable[..., Any]]
    _lib_archive_dominated_by: ClassVar[Callable[..., Any]]
    _lib_archive_dominates: ClassVar[Callable[..., Any]]
    _lib_archive_find_exact_vector: ClassVar[Callable[..., Any]]
    _lib_archive_find_x_values_of_vector: ClassVar[Callable[..., Any]]
    _lib_archive_free: ClassVar[Callable[..., Any]]
    _lib_archive_get_contents: ClassVar[Callable[..., Any]]
    _lib_archive_get_unique_vectors: ClassVar[Callable[..., Any]]
    _lib_archive_iter_free: ClassVar[Callable[..., Any]]
    _lib_archive_iter_new: ClassVar[Callable[..., Any]]
    _lib_archive_iter_next: ClassVar[Callable[..., Any]]
    _lib_archive_new: ClassVar[Callable[..., Any]]
    _lib_archive_total_size: ClassVar[Callable[..., Any]]
    _lib_archive_unique_size: ClassVar[Callable[..., Any]]
    _lib_displaced_free: ClassVar[Callable[..., Any]]
    _lib_displaced_get_x_values: ClassVar[Callable[..., Any]]
    _lib_displaced_total_len: ClassVar[Callable[..., Any]]

    def __init__(
        self,
        dim: int,
        maximise: bool | Sequence[bool],
        keep_duplicates: bool,
        has_x_values: bool,
    ):
        super().__init__(
            dim=dim,
            maximise=maximise,
            keep_duplicates=keep_duplicates,
            has_x_values=has_x_values,
        )
        self.all_displaced_p = ffi.new("bool *")

    def __contains__(self, z: ArrayLike) -> bool:
        """Return true if the given objective vector is archived."""
        z = self._objectives_to_c(z)
        return self._lib_archive_find_exact_vector(self._c_archive, z)

    def __iter__(self) -> Iterator[tuple[np.ndarray, Any]]:
        """Return z vectors and, if available, their associated x object one at a time.

        The z vectors are copies so modifying them does not modify the archive.
        However, for efficiency, iterating does not make copies of the objects.

        Modifying the archive while iterating raises a :exc:`RuntimeError`.

        """
        if len(self) == 0:
            return

        it = self._lib_archive_iter_new(self._c_archive)
        if it == ffi.NULL:
            raise MemoryError("failed to create iterator")
        it = ffi.gc(it, self._lib_archive_iter_free)
        z = np.empty(self._dim)
        x = ffi.new("const void **") if self.has_x_values() else ffi.NULL
        while True:
            z_c = ffi.from_buffer("double []", z)
            rc = self._lib_archive_iter_next(it, z_c, x)
            if rc == 1:
                z *= self._minmax
                x_handle = None if x == ffi.NULL else ffi.from_handle(x[0])
                yield z, x_handle
            elif rc == 0:
                break
            else:
                raise RuntimeError(
                    "invalid 'BaseUnboundedArchive' iterator, did you modify the archive?"
                )

    def __len__(self) -> int:
        """Return the total number of points stored in the archive (including duplicates)."""
        return self._lib_archive_total_size(self._c_archive)

    def __repr__(self) -> str:
        z, x = self.get_contents()
        if x is None:
            return str(z)
        return f"{z}\nx = {x}"

    def unique_len(self) -> int:
        """Return the unique number of points stored in the archive."""
        return self._lib_archive_unique_size(self._c_archive)

    def dominates(self, z: ArrayLike) -> bool:
        """Return true if a point in the archive dominates :code:`z`."""
        z = self._objectives_to_c(z)
        return self._lib_archive_dominates(self._c_archive, z)

    # FIXME: Should this be called is_dominated_by, so you write arch.is_dominated_by(z)?
    def dominated_by(self, z: ArrayLike) -> bool:
        """Return true if all points in the archive are dominated by :code:`z`."""
        z = self._objectives_to_c(z)
        return self._lib_archive_dominated_by(self._c_archive, z)

    def add(self, z: ArrayLike, x: Any = None) -> bool:
        """Add a point if it is not (weakly-)dominated by the archive.

        Points dominated by the added point are discarded. With
        :code:`keep_duplicates=True`, weakly-dominated points are
        accepted. Otherwise, they are rejected.

        Returns
        -------
           ``True`` if added or ``False`` if rejected.
        """
        if x is None:
            return self._add_and_discard_no_x(z)

        return self._add_and_discard_with_x(z, x)

    def add_many(
        self, z: ArrayLike, x: Sequence[Any] | None = None
    ) -> list[bool]:
        """Add several points sequentially and return acceptance as a boolean list."""
        ## FIXME: This may create a copy, then self.add() creates another (and the C code another)
        z = _as_2d_float_array(z, dim=self.dim)
        # Call is_nondominated(points) first. It is much faster than adding the
        # points to the archive one by one. After this operation, we know that
        # a point in z cannot be accepted initially, then eliminated by another
        # point in z, so a return value of True indicates that the point is
        # indeed in the archive.
        ## FIXME: Do this in C.
        nondom = is_nondominated(
            z, maximise=self.maximise, keep_weakly=self.keep_duplicates
        )
        if x is None:
            z = z[nondom, :]
            nondom[nondom] = [self._add_and_discard_no_x(point) for point in z]
        else:
            x = list(x)
            if len(x) != len(z):
                raise ValueError(
                    "'x' must be a list with one value per input vector"
                )
            z = z[nondom, :]
            nondom[nondom] = [
                self._add_and_discard_with_x(point, x_value)
                for point, x_value in zip(z, itertools.compress(x, nondom))
            ]

        return nondom.tolist()

    def _add_and_discard_no_x(self, z: ArrayLike) -> bool:
        # The C code copies z but not x.
        z_c = self._objectives_to_c(z)
        accepted = self._lib_archive_add_and_discard(
            self._c_archive, z_c, ffi.NULL
        )
        match accepted:
            case lib.ARCHIVE_INSERT_ACCEPTED | lib.ARCHIVE_INSERT_DUPLICATED:
                return True
            case lib.ARCHIVE_INSERT_REJECTED:
                return False
            case lib.ARCHIVE_INSERT_X_MUST_BE_NOT_NULL:
                raise ValueError("'x' cannot be None")
            case lib.ARCHIVE_INSERT_MEMORY_ERROR:
                raise MemoryError
            case _:
                raise NotImplementedError("unknown error")

    def _add_and_discard_with_x(self, z: ArrayLike, x: Any) -> bool:
        # The C code copies z but not x.
        z_c = self._objectives_to_c(z)
        x_c = ffi.new_handle(x)
        # Make sure _lib_archive_add_and_get_displaced() starts from an empty
        # list of displaced.
        self.displaced_p[0] = ffi.NULL
        # FIXME: We need to track displaced because we need to clean-up
        # x_handles.  Is there a faster way to do this?
        accepted = self._lib_archive_add_and_get_displaced(
            self._c_archive, z_c, x_c, True, self.displaced_p
        )

        match accepted:
            case lib.ARCHIVE_INSERT_ACCEPTED | lib.ARCHIVE_INSERT_DUPLICATED:
                _remember_handle(self._x_handles, x_c)
                displaced = self.displaced_p[0]
                if displaced != ffi.NULL:
                    displaced = ffi.gc(displaced, self._lib_displaced_free)
                    handles = self._get_x_handles_from_displaced(displaced)
                    for k in handles:
                        del self._x_handles[k]
                return True
            case lib.ARCHIVE_INSERT_REJECTED:
                return False
            case lib.ARCHIVE_INSERT_X_MUST_BE_NOT_NULL:
                raise ValueError("'x' cannot be None")
            case lib.ARCHIVE_INSERT_X_MUST_BE_NULL:
                raise ValueError("'x' must be None")
            case lib.ARCHIVE_INSERT_MEMORY_ERROR:
                raise MemoryError
            case _:
                raise NotImplementedError("unknown error")

    def get_contents(self) -> tuple[np.ndarray, list[Any] | None]:
        """Return the full contents of the archive.

        Returns
        -------
            Tuple of objective vectors (as a Numpy array) and a list of x values (or ``None`` if ``not self.has_x_values()``)

        """
        return self._c_get_contents(self._c_archive, self.dim, self._minmax)

    def get_unique_vectors(self) -> np.ndarray:
        """Return the unique objective vectors stored in the archive."""
        return self._c_get_unique_vectors(
            self._c_archive, self.dim, self._minmax
        )

    def get_x_values(self) -> list[Any]:
        """Return the x-values stored in the archive."""
        if not self.has_x_values():
            raise ValueError("this archive does not store x-values")
        return self._c_get_x_values(self._c_archive)

    def get_x_values_of_vector(self, z: ArrayLike) -> list[Any]:
        """Return the x-values of vector ``z``.

        Returns
        -------
           The list of objects associated to ``z`` in the archive or an empty list if ``z`` is not in the archive. The list may contain more than one element is duplicated ``z`` vectors are stored in the archive.  If the archive does not store x-values, it raises a ``ValueError``.

        """
        if not self.has_x_values():
            raise ValueError("this archive does not store x-values")

        z = self._objectives_to_c(z)
        x_list = self._lib_archive_find_x_values_of_vector(self._c_archive, z)
        if x_list == ffi.NULL:
            return []
        return [ffi.from_handle(x_list.list[i]) for i in range(x_list.n)]

    def _get_x_handles_from_displaced(self, displaced):
        if not self.has_x_values():
            return []

        x_list = ffi.new("void *[]", self._lib_displaced_total_len(displaced))
        self._lib_displaced_get_x_values(displaced, x_list)
        return x_list

    @classmethod
    def _c_get_contents(cls, c_tree, dim, minmax):
        size = cls._lib_archive_total_size(c_tree)
        z_array = np.empty((size, dim), dtype=float)
        z_c = ffi.from_buffer("double []", z_array)
        if cls._lib_archive_has_x_values(c_tree):
            x_list = ffi.new("void *[]", size)
            cls._lib_archive_get_contents(c_tree, z_c, x_list)
            x_list = [ffi.from_handle(x) for x in x_list]
        else:
            cls._lib_archive_get_contents(c_tree, z_c, ffi.NULL)
            x_list = None
        # *= modifies the array in place.
        z_array *= minmax
        return z_array, x_list

    @classmethod
    def _c_get_unique_vectors(cls, c_archive, dim, minmax):
        # FIXME: It would be faster to return a single block of memory, but we
        # need a new function to get the pointer addresses.
        size = cls._lib_archive_unique_size(c_archive)
        if size == 0:
            return []
        z_array = np.empty((size, dim), dtype=float)
        z_c = ffi.from_buffer("double []", z_array)
        cls._lib_archive_get_unique_vectors(c_archive, z_c)
        # *= modifies the array in place.
        z_array *= minmax
        return z_array

    @abstractmethod
    def _lib_archive_insert_displaced(self, displaced) -> tuple[Any, bool]:
        pass

    @staticmethod
    @abstractmethod
    def _c_get_x_values(c_archive) -> list[Any]:
        pass


class NDTreeArchive(BaseUnboundedArchive):
    # C functions
    _lib_archive_add_and_discard = lib.ndtree_add_discard
    _lib_archive_add_and_get_displaced = lib.ndtree_add
    _lib_archive_dominated_by = lib.ndtree_dominated_by
    _lib_archive_dominates = lib.ndtree_dominates
    _lib_archive_find_exact_vector = lib.ndtree_find_exact_vector
    _lib_archive_find_x_values_of_vector = lib.ndtree_find_solutions_of_vector
    _lib_archive_free = lib.ndtree_free
    _lib_archive_get_contents = lib.ndtree_get_contents
    _lib_archive_get_unique_vectors = lib.ndtree_get_unique_vectors
    _lib_archive_has_x_values = lib.ndtree_has_x_values
    _lib_archive_iter_free = lib.ndtree_iter_free
    _lib_archive_iter_new = lib.ndtree_iter_new
    _lib_archive_iter_next = lib.ndtree_iter_next
    _lib_archive_new = lib.ndtree_new
    _lib_archive_total_size = lib.ndtree_total_size
    _lib_archive_unique_size = lib.ndtree_unique_size
    _lib_displaced_free = lib.flex_bucket_free
    _lib_displaced_get_x_values = lib.flex_bucket_get_x_values
    _lib_displaced_total_len = lib.flex_bucket_total_len

    def __init__(
        self,
        dim: int,
        maximise: bool | Sequence[bool] = False,
        max_children: int = 0,
        max_bucket_size: int = 0,
        keep_duplicates: bool = False,
        has_x_values: bool = False,
    ):

        self.max_children, self.max_bucket_size = self._get_default_config(
            dim, max_children, max_bucket_size
        )
        super().__init__(
            dim=dim,
            maximise=maximise,
            keep_duplicates=keep_duplicates,
            has_x_values=has_x_values,
        )
        # We cache these pointers here so we don't keep allocating and freeing memory.
        self.displaced_p = ffi.new("FlexBucket **")

    # This is a @classmethod so we can use it from NDSForestNDTree
    @classmethod
    def _get_default_config(
        cls,
        dim,
        max_children: int,
        max_bucket_size: int,
    ):
        # FIXME: This duplicates the logic in C, it would be better to call a C
        # function.
        max_children = max(dim + 1, max_children)
        if max_children >= 255:
            raise ValueError("'max_children' must be smaller than 255")

        if max_bucket_size < max_children:
            max_bucket_size = 20
        if max_bucket_size >= 255:
            raise ValueError("'max_bucket_size' must be smaller than 255")

        return max_children, max_bucket_size

    def _setup_c_archive(self, keep_duplicates: bool, has_x_values: bool):
        # ffi.gc() ensures that the pointer is registered with the GC and the C
        # destructor called.
        x_is_null = not has_x_values
        return self._lib_archive_new(
            self.dim,
            self.max_children,
            self.max_bucket_size,
            keep_duplicates,
            x_is_null,
        )

    @staticmethod
    def _c_get_x_values(c_archive) -> list[Any]:
        x_list = ffi.new("void *[]", lib.ndtree_total_size(c_archive))
        lib.ndtree_get_x_values(c_archive, x_list)
        x_list = [ffi.from_handle(x) for x in x_list]
        return x_list

    def _lib_archive_insert_displaced(self, displaced) -> tuple[Any, bool]:
        ## FIXME: Reuse the memory instead of allocating a new displaced.
        # lib.ndtree_insert_displaced() will free the current displaced, so
        # Python does not need to do it.
        ffi.gc(displaced, None)
        self.displaced_p[0] = displaced
        lib.ndtree_insert_displaced(
            self._c_archive, self.displaced_p, self.all_displaced_p
        )
        assert displaced != self.displaced_p[0]
        displaced = self.displaced_p[0]
        if displaced != ffi.NULL:
            # lib.ndtree_insert_displaced() may create new memory, so we need ffi.gc().
            displaced = ffi.gc(displaced, self._lib_displaced_free)

        return displaced, self.all_displaced_p[0]


class TreapArchive(BaseUnboundedArchive):
    # C functions
    _lib_archive_add_and_discard = lib.treap_archive_add_discard
    _lib_archive_add_and_get_displaced = lib.treap_archive_add
    _lib_archive_dominated_by = lib.treap_archive_dominated_by
    _lib_archive_dominates = lib.treap_archive_dominates
    _lib_archive_find_exact_vector = lib.treap_archive_find_exact_vector
    _lib_archive_find_x_values_of_vector = (
        lib.treap_archive_find_solutions_of_vector
    )
    _lib_archive_free = lib.treap_archive_free
    _lib_archive_get_contents = lib.treap_archive_get_contents
    _lib_archive_get_unique_vectors = lib.treap_archive_get_unique_vectors
    _lib_archive_has_x_values = lib.treap_archive_has_x_values
    _lib_archive_iter_free = lib.treap_archive_iter_free
    _lib_archive_iter_new = lib.treap_archive_iter_new
    _lib_archive_iter_next = lib.treap_archive_iter_next
    _lib_archive_new = lib.treap_archive_new
    _lib_archive_total_size = lib.treap_archive_total_size
    _lib_archive_unique_size = lib.treap_archive_unique_size
    _lib_displaced_free = lib.treap_archive_free
    _lib_displaced_get_unique_vectors = lib.treap_archive_get_unique_vectors
    _lib_displaced_get_x_values = lib.treap_archive_get_x_values
    _lib_displaced_total_len = lib.treap_archive_total_size

    def __init__(
        self,
        maximise: bool | Sequence[bool],
        keep_duplicates: bool = False,
        has_x_values: bool = False,
    ):
        super().__init__(
            dim=2,
            maximise=maximise,
            keep_duplicates=keep_duplicates,
            has_x_values=has_x_values,
        )
        # We cache these pointers here so we don't keep allocating and freeing memory.
        self.displaced_p = ffi.new("TreapArchive **")

    def _setup_c_archive(self, keep_duplicates: bool, has_x_values: bool):
        x_is_null = not has_x_values
        return self._lib_archive_new(keep_duplicates, x_is_null)

    @staticmethod
    def _c_get_x_values(c_archive) -> list[Any]:
        x_list = ffi.new("void *[]", lib.treap_archive_total_size(c_archive))
        lib.treap_archive_get_x_values(c_archive, x_list)
        x_list = [ffi.from_handle(x) for x in x_list]
        return x_list

    def _lib_archive_insert_displaced(self, displaced) -> tuple[Any, bool]:
        # lib.treap_archive_insert_displaced() does not create new memory, so no ffi.gc().
        lib.treap_archive_insert_displaced(
            self._c_archive, displaced, self.all_displaced_p
        )
        return displaced, self.all_displaced_p[0]


@DocSubstitute()
def UnboundedArchive(  # noqa: N802
    dim: int,
    *,
    maximise: bool | Sequence[bool] = False,
    max_children: int = 0,
    max_bucket_size: int = 0,
    keep_duplicates: bool = False,
    has_x_values: bool = False,
) -> BaseUnboundedArchive:
    """Create an empty unbounded-size nondominated archive. The type of archive built depends on dim.

    A nondominated archive is a data structure that stores only nondominated points and allows efficient updates with new points.  When a new point is added, if the new point is (weakly)-dominated by an existing point in the archive, the point would be rejected. If the new point is not (weakly)-dominated, it will be accepted. Points in the archive (weakly)-dominated by the new one will be removed.  If the archive allows duplicates, then duplicated points, i.e., weakly-dominated but not dominated, are allowed in the archive.

    These archives are unbounded, that is, there is no limit in the number of nondominated points that can be stored in the archive.

    The archive can optionally store an arbitrary Python object (`x`-value) associated to each point. When the archive allows duplicates, duplicated points may be associated to different Python objects.

    When :code:`dim = 2`, the archive is based on a treap data structure :footcite:p:`AraSei1989rst`.
    When :code:`dim > 2`, the archive is based on a ND-Tree :footcite:p:`JasLus2018ndtree`.

    Parameters
    ----------
    dim :
        ${dim}
    maximise :
        ${maximise}
    max_children :
        Maximum number of children used in the ND-Tree (only when :code:`dim > 2`).
    max_bucket_size :
        Maximum number of solutions stored in each leaf of the ND-Tree (only when :code:`dim > 2`).
    keep_duplicates :
        Whether to allow or reject duplicated input points (i.e., objective vectors).
    has_x_values :
        Whether the archive will store a Python object (`x`-value) for each input point (i.e., objective vector).

    Returns
    -------
        Abstract base class that documents the methods available.


    References
    ----------
    .. footbibliography::

    Examples
    --------
    >>> arch = UnboundedArchive(dim=2)
    >>> arch.add_many([[10, 10], [5, 20], [20, 5]])
    [True, True, True]
    >>> arch.add([11, 11])
    False

    The ``len()`` function applied to the archive returns the number of points:

    >>> len(arch)
    3
    >>> arch.add([5, 5])
    True
    >>> len(arch)
    1
    >>> arch.add_many([[6, 4], [4, 6]])
    [True, True]

    We can also iterate over the contents:

    >>> for z, _ in arch:
    ...     print(z)
    [4. 6.]
    [5. 5.]
    [6. 4.]


    It is possible to associate `x`-values to each point and allow duplicates.

    >>> arch = UnboundedArchive(3, keep_duplicates=True, has_x_values=True)
    >>> arch.add_many([[10, 10, 10], [5, 5, 20], [20, 5, 5]], x=["a", "b", "c"])
    [True, True, True]
    >>> len(arch)
    3
    >>> arch.add([9, 9, 9], x="d")
    True
    >>> arch
    [[20.  5.  5.]
     [ 5.  5. 20.]
     [ 9.  9.  9.]]
    x = ['c', 'b', 'd']


    We allowed duplicates in this archive:

    >>> arch.add([9, 9, 9], x="e")
    True
    >>> arch
    [[20.  5.  5.]
     [ 5.  5. 20.]
     [ 9.  9.  9.]
     [ 9.  9.  9.]]
    x = ['c', 'b', 'd', 'e']


    The ``in`` keyword can be used to test if a point is in the archive:

    >>> [9, 9, 9] in arch
    True
    >>> [10, 10, 10] in arch
    False

    And we can retrieve the object associated to a particular point:

    >>> arch.get_x_values_of_vector([9, 9, 9])
    ['d', 'e']
    >>> arch.get_x_values_of_vector([10, 10, 10])
    []

    The contents of the archive can be obtained in different ways:

    >>> arch.get_contents()
    (array([[20.,  5.,  5.],
           [ 5.,  5., 20.],
           [ 9.,  9.,  9.],
           [ 9.,  9.,  9.]]), ['c', 'b', 'd', 'e'])
    >>> arch.get_unique_vectors()
    array([[20.,  5.,  5.],
           [ 5.,  5., 20.],
           [ 9.,  9.,  9.]])
    >>> arch.get_x_values()
    ['c', 'b', 'd', 'e']
    >>> for z, x in arch:
    ...     print(f"{x} -> {z}")
    c -> [20.  5.  5.]
    b -> [ 5.  5. 20.]
    d -> [9. 9. 9.]
    e -> [9. 9. 9.]

    We can also mix maximisation and minimisation objectives:

    >>> arch = UnboundedArchive(dim=2, maximise=[False, True])
    >>> arch.add_many([[10, 10], [9, 9], [0, 0]])
    [True, True, True]
    >>> arch.add([10, 9])
    False
    >>> arch.dominated_by([0, 11])
    True
    >>> arch.dominates([10, 11])
    False
    >>> arch
    [[ 0.  0.]
     [ 9.  9.]
     [10. 10.]]


    """
    if dim > 2:
        return NDTreeArchive(
            dim,
            maximise=maximise,
            max_children=max_children,
            max_bucket_size=max_bucket_size,
            keep_duplicates=keep_duplicates,
            has_x_values=has_x_values,
        )
    if dim == 2:
        return TreapArchive(
            maximise=maximise,
            keep_duplicates=keep_duplicates,
            has_x_values=has_x_values,
        )
    if dim < 2:
        raise ValueError("'dim' cannot be smaller than 2")

    raise NotImplementedError("This type of archive is not implemented yet")
