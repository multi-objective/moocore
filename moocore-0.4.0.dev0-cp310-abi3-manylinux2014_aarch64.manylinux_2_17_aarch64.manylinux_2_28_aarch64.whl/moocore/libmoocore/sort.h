#ifndef   	SORT_H_
# define   	SORT_H_

#include "common.h"

// ---------- Relational functions (return bool) -----------------------------


/*
   x < y, i.e., x is strictly lower than y in all dimensions. Assumes minimization.
*/

static inline bool
strongly_dominates(const double * restrict a, const double * restrict b, dimension_t dim)
{
    ASSUME(dim >= 2);
    for (dimension_t d = 0; d < dim; d++)
        if (a[d] >= b[d])
            return false;
    return true;
}

static inline bool
weakly_dominates(const double * restrict a, const double * restrict b, const dimension_t dim)
{
    ASSUME(dim >= 2);
    /* FIXME: GCC 15.1 can auto-vectorize this loop:

    for (dimension_t d = 0; d < dim; d++)
        if (a[d] > b[d])
            return false;
    return true;

    For GCC 13, we use the following code to help auto-vectorization: */
    // GCC is not able to infer this initialization from ASSUME().
    for (dimension_t d = 0; d < 2; d++)
        if (a[d] > b[d])
            return false;
    // unsigned instead of bool to help auto-vectorization in GCC 13.
    unsigned a_leq_b = true;
    /* FIXME: This vectorized loop does not allow an early exit.  This is bad
       when dim is large but early exits are common. */
    for (dimension_t d = 2; d < dim; d++)
        a_leq_b &= (a[d] <= b[d]);
    return (bool) a_leq_b;
}

static inline bool
any_less_than(const double * restrict a, const double * restrict b, dimension_t dim)
{
    for (dimension_t d = 0; d < dim; d++)
        if (a[d] < b[d])
            return true;
    return false;
}

static inline bool
not_weakly_dominates(const double * restrict a, const double * restrict b, dimension_t dim)
{
    return any_less_than(b, a, dim);
}

static inline bool
lexicographic_less_2d(const double * restrict a, const double * restrict b)
{
    return a[1] < b[1] || (a[1] == b[1] && a[0] <= b[0]);
}

static inline bool
lexicographic_less_3d(const double * restrict a, const double * restrict b)
{
    return a[2] < b[2] || (a[2] == b[2] && lexicographic_less_2d(a, b));
}

static inline bool
all_equal_double(const double * restrict a, const double * restrict b, dimension_t dim)
{
    ASSUME(dim >= 2);
    /* FIXME: GCC 15.1 can auto-vectorize this loop:

    for (dimension_t d = 0; d < dim; d++)
        if (a[d] != b[d])
            return false;
    return true;

    For GCC 13, we use the following code to help auto-vectorization: */
    // GCC is not able to infer this initialization from ASSUME().
    for (dimension_t d = 0; d < 2; d++)
        if (a[d] != b[d])
            return false;
    // unsigned instead of bool to help auto-vectorization in GCC 13.
    unsigned a_eq_b = true;
    /* FIXME: This vectorized loop does not allow an early exit.  This is bad
       when dim is large but early exits are common. */
    for (dimension_t d = 2; d < dim; d++)
        a_eq_b &= (a[d] == b[d]);
    return (bool) a_eq_b;
}

/**
   Return true if a <= b but a != b, false otherwise.
*/
static inline bool
dominates_2d(const double * restrict a, const double * restrict b)
{
    return a[0] <= b[0] && a[1] <= b[1] && (a[0] != b[0] || a[1] != b[1]);
}

static inline bool
dominates(const double * restrict a, const double * restrict b, dimension_t dim)
{
    // FIXME: It may be possible to implement this faster by using an early
    // exit in the first loop.
    return weakly_dominates(a, b, dim) && !all_equal_double(a, b, dim);
}

static inline bool
not_dominates(const double * restrict a, const double * restrict b, dimension_t dim)
{
    // FIXME: It may be possible to implement this faster by using an early
    // exit in the first loop.
    return not_weakly_dominates(a, b, dim) || all_equal_double(a, b, dim);
}

// ---------- Comparison functions (e.g, qsort). Return 'int' ----------------

// General type for comparison functions used in qsort() and qsort_r().
typedef int (*cmp_fun_t)(const void *, const void *);
typedef int (*cmp_r_fun_t) (const void *, const void *, void *);

// See usage below.
#define DEFINE_QSORT_CMP(typed_cmp_fn, elem_type)                              \
    static inline int                                                          \
    typed_cmp_fn(const elem_type restrict, const elem_type restrict);          \
                                                                               \
    _attr_maybe_unused static inline int                                       \
    qsort_##typed_cmp_fn(const void * restrict _a, const void * restrict _b)   \
    {                                                                          \
        const elem_type restrict a = (const elem_type)_a;                      \
        const elem_type restrict b = (const elem_type)_b;                      \
        return typed_cmp_fn(a, b);                                             \
    }                                                                          \
                                                                               \
    _attr_maybe_unused static inline int                                       \
    qsort_r_##typed_cmp_fn(const void * restrict _a, const void * restrict _b, \
                           void * arg _attr_maybe_unused)                      \
    {                                                                          \
        return qsort_##typed_cmp_fn(_a, _b);                                   \
    }                                                                          \
                                                                               \
    static inline int                                                          \
    typed_cmp_fn(const elem_type restrict a, const elem_type restrict b)


/* FIXME: How to automatically check that typeof(*array) is compatible with
   the signature of type_cmp ?

   FIXME: This doesn't work if typed_cmp is not the name of an existing
   function, but an expression or passed as an argument to the caller.
*/
#define qsort_typesafe(array, nmemb, typed_cmp)                                \
    qsort((array), (nmemb), sizeof(*(array)), qsort_##typed_cmp)


static inline int
cmp_double_asc(double a, double b)
{
    // Generates branchless code, thus faster than:
    // return a < b ? -1 : (a > b ? 1 : 0);
    return (a > b) - (a < b);
}

/**
   Compare vectors starting from the last component, where dim is the last
   valid component.
*/
static inline int
cmp_pdouble_asc_rev(const double * restrict a, const double * restrict b, dimension_t dim)
{
    ASSUME(dim >= 1);
    int res = cmp_double_asc(a[dim], b[dim]);
    while (!res && dim > 0) {
        dim--;
        res = cmp_double_asc(a[dim], b[dim]);
    }
    return res;
}

static inline int
qsort_r_cmp_pdouble_asc_rev(const void * restrict _a, const void * restrict _b, void * restrict arg)
{
    const double * restrict a = (const double *)_a;
    const double * restrict b = (const double *)_b;
    const dimension_t dim = *(const dimension_t *)arg;

    return cmp_pdouble_asc_rev(a, b, dim);
}

// Lexicographic order of coordinates: asc y, then asc x
DEFINE_QSORT_CMP(cmp_pdouble_asc_rev_2d, double *)
{
    int cmpx = cmp_double_asc(a[0], b[0]);
    int cmpy = cmp_double_asc(a[1], b[1]);
    return cmpy ? cmpy : cmpx;
}

DEFINE_QSORT_CMP(cmp_pdouble_asc_rev_3d, double *)
{
    int res = cmp_double_asc(a[2], b[2]);
    if (res) return res;
    res = cmp_double_asc(a[1], b[1]);
    if (res) return res;
    return cmp_double_asc(a[0], b[0]);
}

static inline int
cmp_pdouble_asc_only_dim(const double * restrict pa, const double * restrict pb, dimension_t dim)
{
    return cmp_double_asc(pa[dim], pb[dim]);
}

DEFINE_QSORT_CMP(cmp_pdouble_asc_1d, double *)
{
    return cmp_pdouble_asc_only_dim(a, b, 0);
}

DEFINE_QSORT_CMP(cmp_pdouble_asc_only_3d, double *)
{
    return cmp_pdouble_asc_only_dim(a, b, 2);
}

DEFINE_QSORT_CMP(cmp_pdouble_asc_only_4d, double *)
{
    return cmp_pdouble_asc_only_dim(a, b, 3);
}

DEFINE_QSORT_CMP(cmp_pdouble_asc_x_nonzero, double *)
{
    ASSUME(a != b);
    return *a < *b ? -1 : 1;
}

// Deterministic tie-break by pointer value.
DEFINE_QSORT_CMP(cmp_pdouble_asc_y_des_x_nonzero, double *)
{
    const double ax = a[0];
    const double bx = b[0];
    const double ay = a[1];
    const double by = b[1];
    int cmp = cmp_double_asc(ay, by);
    return cmp ? cmp : (ax > bx ? -1 : 1);
}

static inline int
cmp_double_asc_x_asc_y(double ax, double ay, double bx, double by)
{
    // Faster than:
    // return (ax < bx) ? -1 : ((ax > bx) ? 1 :
    //                          ((ay < by) ? -1 : ((ay > by) ? 1 : 0)));
    int cmpx = cmp_double_asc(ax, bx);
    int cmpy = cmp_double_asc(ay, by);
    return cmpx ? cmpx : cmpy;
}

// Ascending lexicographic 2D (ascending x, then ascending y)
DEFINE_QSORT_CMP(cmp_pdouble_asc_x_asc_y, double *)
{
    return cmp_double_asc_x_asc_y(a[0], a[1], b[0], b[1]);
}

// Ascending lexicographic 2D (ascending x, then ascending y)
DEFINE_QSORT_CMP(cmp_ppdouble_asc_x_asc_y, double **)
{
    return cmp_pdouble_asc_x_asc_y(*a, *b);
}

DEFINE_QSORT_CMP(cmp_pdouble_asc_y_asc_z, double *)
{
    return cmp_double_asc_x_asc_y(a[1], a[2], b[1], b[2]);
}


static inline const double **
generate_row_pointers(const double * restrict points, size_t size, dimension_t dim)
{
    const double ** p = (const double **) malloc(size * sizeof(*p));
    for (size_t k = 0; k < size; k++)
        p[k] = points + dim * k;
    return p;
}

static inline const double **
generate_row_pointers_asc_x_asc_y(const double * restrict points, size_t n)
{
    const double ** p = generate_row_pointers(points, n, 2);
    qsort_typesafe(p, n, cmp_ppdouble_asc_x_asc_y);
    return p;
}


static inline const double **
generate_sorted_doublep_2d_filter_by_ref(const double * restrict points,
                                         size_t * restrict size, const double ref0)
{
    size_t n = *size;
    const double ** p = (const double **) malloc(n * sizeof(*p));
    size_t j = 0;
    for (size_t k = 0; k < n; k++) {
        /* There is no point in checking p[k][1] < ref[1] here because the
           algorithms have to check anyway. */
        if (points[2 * k] < ref0) {
            p[j] = points + 2 * k;
            j++;
        }
    }
    n = j;
    if (unlikely(n == 0)) {
        free(p);
    } else {
        qsort_typesafe(p, n, cmp_ppdouble_asc_x_asc_y);
    }

    *size = n;
    return p;
}

#endif 	    /* !SORT_H_ */
